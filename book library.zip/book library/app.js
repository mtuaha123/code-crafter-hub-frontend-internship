// Initialize books array from localStorage
let books = JSON.parse(localStorage.getItem('books')) || [];

document.getElementById('bookForm').addEventListener('submit', addBook);

// Function to add a new book
function addBook(event) {
    event.preventDefault();

    const title = document.getElementById('title').value;
    const author = document.getElementById('author').value;
    const category = document.getElementById('category').value;

    const newBook = {
        id: Date.now(),
        title,
        author,
        category,
        history: []
    };

    books.push(newBook);
    localStorage.setItem('books', JSON.stringify(books));
    document.getElementById('bookForm').reset();

    displayBooks();
}

// Function to display books in the table
function displayBooks() {
    const bookList = document.getElementById('bookList');
    bookList.innerHTML = '';

    books.forEach(book => {
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.category}</td>
            <td>${book.history.length > 0 ? book.history.join(', ') : 'No history'}</td>
            <td><button class="borrow" onclick="borrowBook(${book.id})">Borrow</button></td>
        `;

        bookList.appendChild(row);
    });
}

// Function to borrow a book
function borrowBook(id) {
    const borrower = prompt('Enter your name:');
    if (borrower) {
        const book = books.find(book => book.id === id);
        book.history.push(borrower);

        localStorage.setItem('books', JSON.stringify(books));
        displayBooks();
    }
}

// Function to search books
function searchBook() {
    const searchText = document.getElementById('searchBook').value.toLowerCase();
    const filteredBooks = books.filter(book =>
        book.title.toLowerCase().includes(searchText) ||
        book.author.toLowerCase().includes(searchText) ||
        book.category.toLowerCase().includes(searchText)
    );

    const bookList = document.getElementById('bookList');
    bookList.innerHTML = '';

    filteredBooks.forEach(book => {
        const row = document.createElement('tr');

        row.innerHTML = `
            <td>${book.title}</td>
            <td>${book.author}</td>
            <td>${book.category}</td>
            <td>${book.history.length > 0 ? book.history.join(', ') : 'No history'}</td>
            <td><button class="borrow" onclick="borrowBook(${book.id})">Borrow</button></td>
        `;

        bookList.appendChild(row);
    });
}

// Initial display of books on page load
displayBooks();
