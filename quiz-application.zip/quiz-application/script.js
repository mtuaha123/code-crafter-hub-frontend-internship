const questions = [
    {
        question: "What is the capital of France?",
        choices: ["Berlin", "Madrid", "Paris", "Rome"],
        correctAnswer: "Paris"
    },
    {
        question: "Which language is used for web development?",
        choices: ["Python", "Java", "C#", "JavaScript"],
        correctAnswer: "JavaScript"
    },
    {
        question: "Which planet is known as the Red Planet?",
        choices: ["Earth", "Mars", "Jupiter", "Venus"],
        correctAnswer: "Mars"
    },
    {
        question: "Who wrote 'Hamlet'?",
        choices: ["Charles Dickens", "Leo Tolstoy", "Mark Twain", "William Shakespeare"],
        correctAnswer: "William Shakespeare"
    },
    {
        question: "What is the largest ocean on Earth?",
        choices: ["Atlantic", "Indian", "Arctic", "Pacific"],
        correctAnswer: "Pacific"
    }
];

let currentQuestionIndex = 0;
let score = 0;

const questionElement = document.getElementById("question");
const choicesElement = document.getElementById("choices");
const submitButton = document.getElementById("submit");
const resultElement = document.getElementById("result");
const scoreElement = document.getElementById("score");
const restartButton = document.getElementById("restart");

function loadQuestion() {
    const currentQuestion = questions[currentQuestionIndex];
    questionElement.textContent = currentQuestion.question;
    choicesElement.innerHTML = "";
    currentQuestion.choices.forEach(choice => {
        const li = document.createElement("li");
        li.innerHTML = `<label><input type="radio" name="answer" value="${choice}"> ${choice}</label>`;
        choicesElement.appendChild(li);
    });
}

function checkAnswer() {
    const selectedAnswer = document.querySelector('input[name="answer"]:checked');
    if (selectedAnswer) {
        if (selectedAnswer.value === questions[currentQuestionIndex].correctAnswer) {
            score++;
        }
        currentQuestionIndex++;
        if (currentQuestionIndex < questions.length) {
            loadQuestion();
        } else {
            showResult();
        }
    } else {
        alert("Please select an answer.");
    }
}

function showResult() {
    questionElement.style.display = "none";
    choicesElement.style.display = "none";
    submitButton.style.display = "none";
    resultElement.classList.remove("hidden");
    scoreElement.textContent = `Your score is ${score} out of ${questions.length}`;
}

function restartQuiz() {
    currentQuestionIndex = 0;
    score = 0;
    resultElement.classList.add("hidden");
    questionElement.style.display = "block";
    choicesElement.style.display = "block";
    submitButton.style.display = "block";
    loadQuestion();
}

submitButton.addEventListener("click", checkAnswer);
restartButton.addEventListener("click", restartQuiz);

loadQuestion();
