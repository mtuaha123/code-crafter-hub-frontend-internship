import React, { useState } from 'react';
import './App.css'; // Ensure you have this CSS file for custom styles

function App() {
  const [tasks, setTasks] = useState([
    { id: "todo-0", name: "Eat", completed: true },
    { id: "todo-1", name: "Sleep", completed: false },
    { id: "todo-2", name: "Repeat", completed: false }
  ]);

  const [newTask, setNewTask] = useState('');
  const [filter, setFilter] = useState('all');

  const handleInputChange = (e) => {
    setNewTask(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (newTask.trim() === '') return;
    const newTaskObj = {
      id: `todo-${tasks.length}`,
      name: newTask,
      completed: false
    };
    setTasks([...tasks, newTaskObj]);
    setNewTask('');
  };

  const deleteTask = (id) => {
    const remainingTasks = tasks.filter(task => task.id !== id);
    setTasks(remainingTasks);
  };

  const [editingTask, setEditingTask] = useState(null);
  const [editedTaskName, setEditedTaskName] = useState('');

  const handleEditChange = (e) => {
    setEditedTaskName(e.target.value);
  };

  const startEditing = (task) => {
    setEditingTask(task.id);
    setEditedTaskName(task.name);
  };

  const saveEdit = (id) => {
    const updatedTasks = tasks.map(task => {
      if (task.id === id) {
        return { ...task, name: editedTaskName };
      }
      return task;
    });
    setTasks(updatedTasks);
    setEditingTask(null);
  };

  const handleFilterChange = (filter) => {
    setFilter(filter);
  };

  const getFilteredTasks = () => {
    switch (filter) {
      case 'active':
        return tasks.filter(task => !task.completed);
      case 'completed':
        return tasks.filter(task => task.completed);
      default:
        return tasks;
    }
  };

  const filteredTasks = getFilteredTasks();

  return (
    <div className="todoapp">
      <h1 className="header">TodoMatic</h1>
      <form onSubmit={handleSubmit} className="task-form">
        <h2 className="form-label">
          <label htmlFor="new-todo-input" className="label">
            What's your next task?
          </label>
        </h2>
        <input
          type="text"
          id="new-todo-input"
          className="input"
          name="text"
          autoComplete="off"
          value={newTask}
          onChange={handleInputChange}
        />
        <button type="submit" className="btn btn-add">
          Add Task
        </button>
      </form>
      <div className="filter-buttons">
        <button
          type="button"
          className={`btn filter-btn ${filter === 'all' ? 'active' : ''}`}
          onClick={() => handleFilterChange('all')}
        >
          All
        </button>
        <button
          type="button"
          className={`btn filter-btn ${filter === 'active' ? 'active' : ''}`}
          onClick={() => handleFilterChange('active')}
        >
          Active
        </button>
        <button
          type="button"
          className={`btn filter-btn ${filter === 'completed' ? 'active' : ''}`}
          onClick={() => handleFilterChange('completed')}
        >
          Completed
        </button>
      </div>
      <h2 className="tasks-heading">{filteredTasks.length} task{filteredTasks.length !== 1 ? 's' : ''} remaining</h2>
      <ul className="task-list">
        {filteredTasks.map(task => (
          <li key={task.id} className="task-item">
            <input
              id={task.id}
              type="checkbox"
              checked={task.completed}
              onChange={() => {
                const updatedTasks = tasks.map(t => 
                  t.id === task.id ? { ...t, completed: !t.completed } : t
                );
                setTasks(updatedTasks);
              }}
            />
            {editingTask === task.id ? (
              <>
                <input
                  type="text"
                  value={editedTaskName}
                  onChange={handleEditChange}
                  className="edit-input"
                />
                <button onClick={() => saveEdit(task.id)} className="btn btn-save">
                  Save
                </button>
              </>
            ) : (
              <label className="task-label" htmlFor={task.id}>
                {task.name}
              </label>
            )}
            <div className="task-buttons">
              {editingTask === task.id ? (
                <button type="button" className="btn btn-cancel" onClick={() => setEditingTask(null)}>
                  Cancel
                </button>
              ) : (
                <>
                  <button type="button" className="btn btn-edit" onClick={() => startEditing(task)}>
                    Edit
                  </button>
                  <button
                    type="button"
                    className="btn btn-delete"
                    onClick={() => deleteTask(task.id)}>
                    Delete
                  </button>
                </>
              )}
            </div>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default App;
