(function() {
    const quizContainer = document.getElementById('quiz');
    const resultsContainer = document.getElementById('results');
    const submitButton = document.getElementById('submit');
  
    const quizQuestions = [
      {
        question: "Who holds the record for the highest individual score in Test cricket?",
        answers: {
          a: "Brian Lara",
          b: "Sachin Tendulkar",
          c: "Ricky Ponting"
        },
        correctAnswer: "a"
      },
      {
        question: "Which country has won the most ICC Cricket World Cups?",
        answers: {
          a: "Australia",
          b: "India",
          c: "West Indies"
        },
        correctAnswer: "a"
      },
      {
        question: "What is the maximum number of overs allowed per bowler in a T20 match?",
        answers: {
          a: "4",
          b: "5",
          c: "6"
        },
        correctAnswer: "a"
      },
      {
        question: "Which cricketer is known as the 'God of Cricket'?",
        answers: {
          a: "Virat Kohli",
          b: "Don Bradman",
          c: "Sachin Tendulkar"
        },
        correctAnswer: "c"
      },
      {
        question: "Who was the captain of the Indian cricket team when they won the 2011 World Cup?",
        answers: {
          a: "Virat Kohli",
          b: "MS Dhoni",
          c: "Sourav Ganguly"
        },
        correctAnswer: "b"
      }
    ];
  
    function buildQuiz() {
      const output = [];
  
      quizQuestions.forEach((currentQuestion, questionNumber) => {
        const answers = [];
  
        for (letter in currentQuestion.answers) {
          answers.push(
            `<label>
              <input type="radio" name="question${questionNumber}" value="${letter}">
              ${letter}: ${currentQuestion.answers[letter]}
            </label>`
          );
        }
  
        output.push(
          `<div class="question"> ${currentQuestion.question} </div>
          <div class="answers"> ${answers.join('')} </div>`
        );
      });
  
      quizContainer.innerHTML = output.join('');
    }
  
    function showResults() {
      const answerContainers = quizContainer.querySelectorAll('.answers');
      let numCorrect = 0;
  
      quizQuestions.forEach((currentQuestion, questionNumber) => {
        const answerContainer = answerContainers[questionNumber];
        const selector = `input[name=question${questionNumber}]:checked`;
        const userAnswer = (answerContainer.querySelector(selector) || {}).value;
  
        if (userAnswer === currentQuestion.correctAnswer) {
          numCorrect++;
          answerContainers[questionNumber].style.color = 'green';
        } else {
          answerContainers[questionNumber].style.color = 'red';
        }
      });
  
      resultsContainer.innerHTML = `You got ${numCorrect} out of ${quizQuestions.length} correct.`;
    }
  
    buildQuiz();
  
    submitButton.addEventListener('click', showResults);
  })();
  